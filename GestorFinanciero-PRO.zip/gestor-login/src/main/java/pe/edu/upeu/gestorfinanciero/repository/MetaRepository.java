package pe.edu.upeu.gestorfinanciero.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import pe.edu.upeu.gestorfinanciero.model.Meta;

import java.util.List;

public interface MetaRepository extends JpaRepository<Meta, Long> {
    @Query(value = "SELECT m.* FROM upeu_meta m WHERE m.nombre like:filter", nativeQuery = true)
    List<Meta> listAutoCompletMeta(@Param("filter") String filter);

    // Metas de un usuario específico (para el rol USUARIO)
    List<Meta> findByUsuario_IdUsuario(Long idUsuario);
}
