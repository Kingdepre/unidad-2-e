package pe.edu.upeu.gestorfinanciero.service;

import pe.edu.upeu.gestorfinanciero.model.Usuario;
import java.util.List;

public interface UsuarioIService {
    Usuario findById(Long id);
    Usuario autenticar(String username, String password);
    List<Usuario> findAll();
    Usuario save(Usuario usuario);
    void delete(Long id);
    boolean existeUsername(String username);
}
