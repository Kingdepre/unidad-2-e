package pe.edu.upeu.gestorfinanciero.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.gestorfinanciero.dto.SessionManager;
import pe.edu.upeu.gestorfinanciero.model.Usuario;
import pe.edu.upeu.gestorfinanciero.service.UsuarioIService;

@Controller
public class LoginController {

    @FXML
    private TextField txtUsuario;
    @FXML
    private PasswordField txtClave;
    @FXML
    private Label lblMensaje;

    @Autowired
    private UsuarioIService usuarioIService;
    @Autowired
    private ApplicationContext context;

    @FXML
    public void iniciarSesion() {
        String user = txtUsuario.getText().trim();
        String pass = txtClave.getText().trim();

        if (user.isEmpty() || pass.isEmpty()) {
            mostrarError("Ingrese usuario y contraseña");
            return;
        }

        Usuario usuario = usuarioIService.autenticar(user, pass);
        if (usuario == null) {
            mostrarError("Usuario o contraseña incorrectos");
            return;
        }

        // Guardar la sesión del usuario autenticado
        SessionManager sesion = SessionManager.getInstance();
        sesion.setUserId(usuario.getIdUsuario());
        sesion.setUserName(usuario.getNombre());
        sesion.setUserPerfil(usuario.getRol());

        abrirPantallaMetas();
    }

    private void abrirPantallaMetas() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/main_meta.fxml"));
            loader.setControllerFactory(context::getBean);
            Parent root = loader.load();

            Stage stage = (Stage) txtUsuario.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/css/styles.css").toExternalForm());
            stage.setScene(scene);
            stage.setTitle("Gestor-Finanzas");
            stage.centerOnScreen();
        } catch (Exception e) {
            mostrarError("No se pudo abrir la aplicación");
            e.printStackTrace();
        }
    }

    private void mostrarError(String msg) {
        lblMensaje.setText(msg);
        lblMensaje.setStyle("-fx-text-fill: #c0392b; -fx-font-size: 13px;");
    }
}
