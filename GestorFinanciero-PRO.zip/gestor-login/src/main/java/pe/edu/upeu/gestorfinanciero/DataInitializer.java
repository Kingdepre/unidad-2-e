package pe.edu.upeu.gestorfinanciero;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import pe.edu.upeu.gestorfinanciero.model.Usuario;
import pe.edu.upeu.gestorfinanciero.repository.UsuarioRepository;

// Crea usuarios iniciales para poder iniciar sesión la primera vez.
@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;

    public DataInitializer(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    public void run(String... args) {
        if (usuarioRepository.findByUsername("admin").isEmpty()) {
            Usuario admin = Usuario.builder()
                    .nombre("Administrador")
                    .username("admin")
                    .password("123456")
                    .rol("ADMIN")
                    .build();
            usuarioRepository.save(admin);
        }
        if (usuarioRepository.findByUsername("usuario").isEmpty()) {
            Usuario user = Usuario.builder()
                    .nombre("Isai Mamani")
                    .username("usuario")
                    .password("123456")
                    .rol("USUARIO")
                    .build();
            usuarioRepository.save(user);
        }
    }
}
