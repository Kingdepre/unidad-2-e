package pe.edu.upeu.gestorfinanciero.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upeu.gestorfinanciero.model.Usuario;
import pe.edu.upeu.gestorfinanciero.repository.UsuarioRepository;
import pe.edu.upeu.gestorfinanciero.service.UsuarioIService;

import java.util.List;

@Service
public class UsuarioIServiceImp implements UsuarioIService {
    @Autowired
    UsuarioRepository uRepo;

    @Override
    public Usuario findById(Long id) {
        return uRepo.findById(id).orElse(null);
    }

    @Override
    public Usuario autenticar(String username, String password) {
        return uRepo.findByUsername(username)
                .filter(u -> u.getPassword().equals(password))
                .orElse(null);
    }

    @Override
    public List<Usuario> findAll() {
        return uRepo.findAll();
    }

    @Override
    public Usuario save(Usuario usuario) {
        return uRepo.save(usuario);
    }

    @Override
    public void delete(Long id) {
        uRepo.deleteById(id);
    }

    @Override
    public boolean existeUsername(String username) {
        return uRepo.findByUsername(username).isPresent();
    }
}
