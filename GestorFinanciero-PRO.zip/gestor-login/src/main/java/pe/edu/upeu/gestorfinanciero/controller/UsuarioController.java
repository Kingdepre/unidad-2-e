package pe.edu.upeu.gestorfinanciero.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.gestorfinanciero.dto.SessionManager;
import pe.edu.upeu.gestorfinanciero.model.Usuario;
import pe.edu.upeu.gestorfinanciero.service.UsuarioIService;

@Controller
public class UsuarioController {

    @FXML private TextField txtNombre, txtUsername;
    @FXML private PasswordField txtPassword;
    @FXML private ComboBox<String> cbRol;
    @FXML private TableView<Usuario> tablaUsuarios;
    @FXML private TableColumn<Usuario, Long> colId;
    @FXML private TableColumn<Usuario, String> colNombre, colUsername, colRol;
    @FXML private TableColumn<Usuario, Void> colAcciones;
    @FXML private Label lblMsg;
    @FXML private AnchorPane root;

    @Autowired private UsuarioIService usuarioIService;
    @Autowired private ApplicationContext context;

    private Long idEdicion = 0L;

    @FXML
    public void initialize() {
        cbRol.setItems(FXCollections.observableArrayList("ADMIN", "USUARIO"));
        cbRol.getSelectionModel().select("USUARIO");

        colId.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("idUsuario"));
        colNombre.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("nombre"));
        colUsername.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("username"));
        colRol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("rol"));
        agregarBotonesAccion();
        listar();
    }

    private void listar() {
        ObservableList<Usuario> data = FXCollections.observableArrayList(usuarioIService.findAll());
        tablaUsuarios.setItems(data);
    }

    private void agregarBotonesAccion() {
        colAcciones.setCellFactory(col -> new TableCell<>() {
            private final Button btnEditar = new Button("Editar");
            private final Button btnEliminar = new Button("Eliminar");
            private final HBox caja = new HBox(6, btnEditar, btnEliminar);
            {
                btnEditar.getStyleClass().addAll("btn", "btn-primary");
                btnEliminar.getStyleClass().addAll("btn", "btn-danger");
                btnEditar.setOnAction(e -> {
                    Usuario u = getTableView().getItems().get(getIndex());
                    cargarEnFormulario(u);
                });
                btnEliminar.setOnAction(e -> {
                    Usuario u = getTableView().getItems().get(getIndex());
                    eliminar(u);
                });
            }
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : caja);
            }
        });
    }

    private void cargarEnFormulario(Usuario u) {
        txtNombre.setText(u.getNombre());
        txtUsername.setText(u.getUsername());
        txtPassword.setText(u.getPassword());
        cbRol.getSelectionModel().select(u.getRol());
        idEdicion = u.getIdUsuario();
    }

    @FXML
    public void guardar() {
        String nombre = txtNombre.getText().trim();
        String username = txtUsername.getText().trim();
        String password = txtPassword.getText().trim();
        String rol = cbRol.getValue();

        if (nombre.isEmpty() || username.isEmpty() || password.isEmpty()) {
            error("Complete todos los campos");
            return;
        }
        // Si es nuevo y el username ya existe, rechazar
        if (idEdicion == 0L && usuarioIService.existeUsername(username)) {
            error("El nombre de usuario ya existe");
            return;
        }
        Usuario u = Usuario.builder()
                .nombre(nombre).username(username).password(password).rol(rol)
                .build();
        if (idEdicion > 0L) u.setIdUsuario(idEdicion);
        usuarioIService.save(u);
        ok(idEdicion > 0L ? "Usuario actualizado" : "Usuario creado");
        limpiar();
        listar();
    }

    private void eliminar(Usuario u) {
        // No permitir borrarse a si mismo
        if (u.getIdUsuario().equals(SessionManager.getInstance().getUserId())) {
            error("No puede eliminar su propio usuario en sesión");
            return;
        }
        usuarioIService.delete(u.getIdUsuario());
        ok("Usuario eliminado");
        listar();
    }

    @FXML
    public void limpiar() {
        txtNombre.clear(); txtUsername.clear(); txtPassword.clear();
        cbRol.getSelectionModel().select("USUARIO");
        idEdicion = 0L;
    }

    @FXML
    public void volver() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/main_meta.fxml"));
            loader.setControllerFactory(context::getBean);
            Parent p = loader.load();
            Stage st = (Stage) root.getScene().getWindow();
            Scene sc = new Scene(p);
            sc.getStylesheets().add(getClass().getResource("/css/styles.css").toExternalForm());
            st.setScene(sc);
            st.setTitle("Gestor-Finanzas");
            st.centerOnScreen();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void error(String m) { lblMsg.setText(m); lblMsg.setStyle("-fx-text-fill:#c0392b;-fx-font-size:13px;"); }
    private void ok(String m) { lblMsg.setText(m); lblMsg.setStyle("-fx-text-fill:#1e7e34;-fx-font-size:13px;"); }
}
